using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class TripRepository : ITripRepository
    {
        private NpgsqlConnection _conn;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public TripRepository(IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _conn = new NpgsqlConnection(config.GetConnectionString("pgconn"));
            _httpContextAccessor = httpContextAccessor;
        }

        public void Login(string email, string password)
        {
            try
            {
                _conn.Open();

                using var cmd = new NpgsqlCommand("select c_regid,c_email,c_password,c_role from t_register where c_email=@email and c_password=@password", _conn);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@password", password);

                var reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    var session = _httpContextAccessor.HttpContext.Session;

                    session.SetString("role", reader["c_role"].ToString());

                    session.SetInt32("userid", (int)reader["c_regid"]);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }
            finally
            {
                _conn.Close();
            }
        }
        public void AddTrip(tblTripDetails trip)
        {
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("insert into t_tripdetails(c_tid,c_price,c_ticketstock,c_currentstock,c_userid)values(@tid,@price,@ticketstock,@currentstock,@userid)", conn);
                    cmd.Parameters.AddWithValue("@tid", trip.c_tid);
                    cmd.Parameters.AddWithValue("@price", trip.c_price);
                    cmd.Parameters.AddWithValue("@currentstock", trip.c_currentstock);
                    cmd.Parameters.AddWithValue("@ticketstock", trip.c_ticketstock);
                    var session = _httpContextAccessor.HttpContext.Session;
                    var userid = session.GetInt32("c_regid") ?? 0;
                    cmd.Parameters.AddWithValue("@userid", userid);

                    cmd.ExecuteNonQuery();



                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public void UpdateTrip(tblTripDetails trip)
        {
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("update t_tripdetails set c_tid=@tid,c_price=@price,c_currentstock=@currentstock,c_ticketstock=@ticketstock where c_tripid=@id", conn);
                    cmd.Parameters.AddWithValue("@id", trip.c_tripid);
                    cmd.Parameters.AddWithValue("@tid", trip.c_tid);
                    cmd.Parameters.AddWithValue("@price", trip.c_price);
                    cmd.Parameters.AddWithValue("@currentstock", trip.c_currentstock);
                    cmd.Parameters.AddWithValue("@ticketstock", trip.c_ticketstock);


                    cmd.ExecuteNonQuery();



                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public List<tblTripDetails> GetAllTrips()
        {
            var trips = new List<tblTripDetails>();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))
            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("select tr.c_tripid,tr.c_price,tr.c_ticketstock,tr.c_currentstock,t.c_tripname,tr.c_tid from t_tripdetails tr inner join t_trip t on tr.c_tid=t.c_tid;", conn);

                    var reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        var trip = new tblTripDetails
                        {
                            c_tripid = Convert.ToInt32(reader["c_tripid"]),
                            c_tid = Convert.ToInt32(reader["c_tid"]),
                            c_price = Convert.ToInt32(reader["c_price"]),
                            c_ticketstock = Convert.ToInt32(reader["c_ticketstock"]),
                            c_currentstock = Convert.ToInt32(reader["c_currentstock"]),
                            tripname = reader["c_tripname"].ToString()



                        };
                        trips.Add(trip);
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();
                }

            }
            return trips;
        }
        public tblTripDetails GetOneTrip(int id)
        {
            var trip = new tblTripDetails();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))

            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("select c_tripid,c_tid,c_price,c_ticketstock,c_currentstock from t_tripdetails where c_tripid=@id", conn);
                    cmd.Parameters.AddWithValue("@id", id);

                    var reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        trip.c_tripid = Convert.ToInt32(reader["c_tripid"]);
                        trip.c_tid = Convert.ToInt32(reader["c_tid"]);
                        trip.c_price = Convert.ToInt32(reader["c_price"]);
                        trip.c_ticketstock = Convert.ToInt32(reader["c_ticketstock"]);
                        trip.c_currentstock = Convert.ToInt32(reader["c_currentstock"]);

                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();

                }

            }
            return trip;
        }

        public void DeleteTrip(int id)
        {
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))

            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("Delete from t_tripdetails where c_tripid=@id", conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public List<tblTrip> GetAllTripDetail()
        {
            var trips = new List<tblTrip>();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))

            {

                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("select c_tid ,c_tripname from t_trip", conn);

                    using var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var trip = new tblTrip
                        {
                            c_tid = Convert.ToInt32(reader["c_tid"]),
                            c_tripname = reader["c_tripname"].ToString(),
                        };
                        trips.Add(trip);
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            return trips;
        }

        public void BookTrip(tblTripDetails trip)
        {
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))

            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("update t_tripdetails set c_tid=@tid,c_date=@date,c_quantity=@quantity,c_total=@total,c_currentstock=c_currentstock - @quantity,c_status='Scheduled' where c_tripid=@id ", conn);
                    cmd.Parameters.AddWithValue("@id", trip.c_tripid);
                    cmd.Parameters.AddWithValue("@tid", trip.c_tid);
                    cmd.Parameters.AddWithValue("@date", trip.c_date);
                    cmd.Parameters.AddWithValue("@quantity", trip.c_quantity);
                    cmd.Parameters.AddWithValue("@total", trip.c_total);

                    cmd.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();

                }
            }
        }

        public tblTripDetails GetCurrentStock(int id)
        {
            var trip=new tblTripDetails();
             using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))

            {
            try{
                conn.Open();

                using var cmd=new NpgsqlCommand("select c_currentstock from t_tripdetails where c_tid=@id",conn);

                cmd.Parameters.AddWithValue("@id",id);

                var reader=cmd.ExecuteReader();

                if(reader.Read()){
                    trip.c_currentstock=Convert.ToInt32(reader["c_currentstock"]);

                }

            }catch(Exception e){
                Console.WriteLine(e.Message);
            }finally{
                conn.Close();

            }

            }
            return trip;
        }


public tblTripDetails GetOneBookTrip(int id)
        {
            var trip = new tblTripDetails();
            using (var conn = new NpgsqlConnection("Host=localhost;Username=postgres;Password=Divesh@007;Database=OfflineExamPrac;"))

            {
                try
                {
                    conn.Open();

                    using var cmd = new NpgsqlCommand("select c_tripid,c_tid,c_price,c_currentstock from t_tripdetails where c_tripid=@id", conn);
                    cmd.Parameters.AddWithValue("@id", id);

                    var reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        trip.c_tripid = Convert.ToInt32(reader["c_tripid"]);
                        trip.c_tid = Convert.ToInt32(reader["c_tid"]);
                        trip.c_price = Convert.ToInt32(reader["c_price"]);
                        trip.c_currentstock = Convert.ToInt32(reader["c_currentstock"]);

                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();

                }

            }
            return trip;
        }


    }
}