using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.Interface
{
    public interface ITripRepository
    {
         public void Login(string email,string password);

           public void AddTrip(tblTripDetails trip);

            public void UpdateTrip(tblTripDetails trip);

             public List<tblTripDetails> GetAllTrips();

              public tblTripDetails GetOneTrip(int id);

               public void DeleteTrip(int id);

                public List<tblTrip> GetAllTripDetail();

                 public tblTripDetails GetCurrentStock(int id);

                  public void BookTrip(tblTripDetails trip);

                  public tblTripDetails GetOneBookTrip(int id);
    }
}