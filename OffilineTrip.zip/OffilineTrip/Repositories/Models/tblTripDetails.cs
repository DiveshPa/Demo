using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class tblTripDetails
    {
        public int c_tripid{get;set;}

        public int c_tid{get;set;}

        public int c_price{get;set;}

        public int c_ticketstock{get;set;}

         public int c_currentstock{get;set;}

          public int c_status{get;set;}

          public int c_userid{get;set;}

          public int c_quantity{get;set;}

          public int c_total{get;set;}

          public DateTime c_date{get;set;}

          public string tripname{get;set;} 
    }
}