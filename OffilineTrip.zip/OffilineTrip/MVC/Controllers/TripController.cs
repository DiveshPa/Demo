using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class TripController : Controller
    {
        private readonly ITripRepository _tripRepository;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public TripController(ITripRepository tripRepository,IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor=httpContextAccessor;
           _tripRepository=tripRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

         public IActionResult IndexCustomer()
        {
            List<tblTripDetails> trips=_tripRepository.GetAllTrips();
            return View(trips);
        }

        public IActionResult Login()
        {
             var session=_httpContextAccessor.HttpContext.Session;
            int userid=session.GetInt32("userid")??0;
            string userrole=session.GetString("role");

            Console.WriteLine(userrole);
            Console.WriteLine(userid);

            return View();
        }
        [HttpPost]
        public IActionResult Login(tblRegister user)
        {
            var session=_httpContextAccessor.HttpContext.Session;
            int userid=session.GetInt32("userid")??0;
            string userrole=session.GetString("role");

            Console.WriteLine(userrole);

            _tripRepository.Login(user.c_email,user.c_password);

            if(!string.IsNullOrEmpty(userrole)){
                return Json(new{role=userrole,id=userid});

            }
            return Json(new{message="Login Unsucessfull"});

        }
        public IActionResult GetAll()
        {

            return Json(_tripRepository.GetAllTrips());
        }
        public IActionResult GetAllTrips()
        {
            return Json(_tripRepository.GetAllTripDetail());
        }
        public IActionResult Create()
        {
            return View();
        }

       
        [HttpPost]
        public IActionResult Create(tblTripDetails trip)
        {
           
           _tripRepository.AddTrip(trip);
            return Json("Index");


        }

               public IActionResult Edit(int id)
        {
            var model = _tripRepository.GetOneTrip(id);
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(tblTripDetails trip)
        {
            

            _tripRepository.UpdateTrip(trip);
            return Json("Index");


        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            _tripRepository.DeleteTrip(id);
            return RedirectToAction("Index");
        }

         [HttpPost]
    public IActionResult DeleteSelected(int[] selectedProducts)
    {
        

        if(selectedProducts != null && selectedProducts.Length > 0)
        {
            foreach(var productId in selectedProducts)
            {
                 _tripRepository.DeleteTrip(productId);
            }

            return Ok(new { message = "Products deleted successfully" });
        }
        else
        {
            return BadRequest(new { message = "No products selected for deletion" });
        }
    }

    [HttpGet]
        public IActionResult GetTrip(int id)
        {
    
            var emp = _tripRepository.GetOneBookTrip(id);
             Console.WriteLine(id);
            return Json(emp);
        }
         [HttpGet]
        public IActionResult GetTripCurrentStock(int id)
        {
    
            var emp = _tripRepository.GetCurrentStock(id);
             Console.WriteLine(id);
            return Json(emp);
        }

public IActionResult Book(int id)
        {
            var model = _tripRepository.GetOneBookTrip(id);
            return View(model);
        }
        [HttpPost]
        public IActionResult Book(tblTripDetails trip)
        {
            

            _tripRepository.BookTrip(trip);
            return Json("Index");


        }
         [Produces("application/json")]
        public IActionResult ListAllTrips()
        {
            List<tblTrip> depts = _tripRepository.GetAllTripDetail();
            return Json(depts);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}